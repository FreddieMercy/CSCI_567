python3 -W ignore classification.py --type multiclass --output multiclass.out
rm -rf __pycache__